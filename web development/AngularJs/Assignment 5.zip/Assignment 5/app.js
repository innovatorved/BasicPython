var next = angular.module('nextin' , ['ngAnimate'])

next.controller('nameCon',function($scope)
{
	$scope.msg = 'hloo! i am Ved Gupta. Founder and C.E.O of Next Innovation';
	$scope.Food = ["Chana masala" , "Daal baati churma" , "Dal makhani (kali dal)" , "Dal fara" , "Dum aloo"];;
})