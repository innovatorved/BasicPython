var me = angular.module("myinfo" , ['ngRoute' , 'ngAnimate']);

me.config(["$routeProvider" , function($routeProvider)
{
	$routeProvider
	.when('/',{ templateUrl : "view/home.html" , controller : "dataCon"})

	.when('/movie',{ templateUrl : "view/movie.html" , controller : "dataCon"})

	.when('/tv',{ templateUrl : "view/tv.html" , controller : "dataCon"})

	.when('/tech',{ templateUrl : "view/tech.html" , controller : "dataCon"})

	.when('/food',{ templateUrl : "view/food.html" , controller : "dataCon"})

	.when('/person',{ templateUrl : "view/person.html" , controller : "dataCon"})

	.when('/Me',{ templateUrl : "view/me.html" , controller : "dataCon"})
}]);

me.controller("dataCon" , function($scope)
{
	$scope.home_p1 = ['Before we move on any further - ','Let me introduce myself.'];

	$scope.home_p2 = ['I am Ved Prakash Gupta. I am from Barabanki nearest to Lucknow.','I am pursuing a diploma in Electronic Engineering from the Prestigious Government Polytechnic Bahraich Institute.','I love to make IoT projects and Explore more of My self.'];

	$scope.movie_1 = ['Avengers: Age of Ultron' , ' Is a 2015 American superhero film based on the Marvel Comics superhero team the Avengers,',' produced by Marvel Studios and distributed by Walt Disney Studios Motion Pictures.',' It is the sequel to The Avengers (2012) and the 11th film in the Marvel Cinematic Universe (MCU).'];

	$scope.movie_2 = ['Thugs of Hindostan' , ' Is a 2018 Indian Hindi-language action-adventure film written and directed by Vijay Krishna Acharya,' , ' and produced by Aditya Chopra under his banner Yash Raj Films.' , 'The film stars Amitabh Bachchan, Aamir Khan, Fatima Sana Shaikh and Katrina Kaif.'];

	$scope.movie_3 = ['khatarnak khiladi 2' , 'Is a 2014 Indian Tamil-language action thriller film directed by N. Lingusamy ','and produced under his banner Thirupathi Brothers.',' The film stars Suriya and Vidyut Jammwal in the lead roles,',' while Samantha , Manoj Bajpaee and Dalip Tahil appear in supporting characters.',' The project was materialized in October 2013, with the principal photography took place on 20 November 2013',' in Mumbai and Goa, and was completed in June 2014.'];

	$scope.movie_info = [
	{ 
		name : 'Avengers: Age of Ultron',
		p1 : 'Is a 2015 American superhero film based on the Marvel Comics superhero team the Avengers,',
		p2 : 'produced by Marvel Studios and distributed by Walt Disney Studios Motion Pictures.',
		p3 : 'It is the sequel to The Avengers (2012) and the 11th film in the Marvel Cinematic Universe (MCU).'

	},
	{ 
		name : 'Thugs of Hindostan',
		p1 : 'Is a 2018 Indian Hindi-language action-adventure film written and directed by Vijay Krishna Acharya,',
		p2 : 'and produced by Aditya Chopra under his banner Yash Raj Films.',
		p3 : 'The film stars Amitabh Bachchan, Aamir Khan, Fatima Sana Shaikh and Katrina Kaif.'

	},
	{ 
		name : 'khatarnak khiladi 2',
		p1 : 'Is a 2014 Indian Tamil-language action thriller film directed by N. Lingusamy and produced under his banner Thirupathi Brothers. The film stars Suriya and Vidyut Jammwal in the lead roles,',
		p2 : 'The film stars Suriya and Vidyut Jammwal in the lead roles while Samantha , Manoj Bajpaee and Dalip Tahil appear in supporting characters.',
		p3 : 'The project was materialized in October 2013, and was completed in June 2014.'
		
	}]

	$scope.Food = ["Chana masala" , "Daal baati churma" , "Dal makhani (kali dal)" , "Dal fara" , "Dum aloo"];
});
